package com.vn.dao;

import java.util.List;

import com.vn.entity.Student;

public interface StudentDAO {
	
	public Student addStudent(Student entity);
	
	public List<Student> findAll(Student entity);

}
