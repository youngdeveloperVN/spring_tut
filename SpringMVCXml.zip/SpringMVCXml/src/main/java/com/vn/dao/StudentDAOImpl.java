package com.vn.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.vn.consts.QueryConst;
import com.vn.entity.Student;
import com.vn.mapper.StudentMapper;

public class StudentDAOImpl implements StudentDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Student addStudent(Student entity) {
		int number  = jdbcTemplate.update(QueryConst.STUDENT_DML_INSERT);
		if(number > 0 ) {
			return entity;
		}
		return null;
	}

	public List<Student> findAll(Student entity) {
		List<Student> list = jdbcTemplate.query(QueryConst.STUDENT_DML_INSERT, new StudentMapper());
		return list;
	}

}
