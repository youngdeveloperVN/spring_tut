package com.vn.service;

import java.util.List;

import com.vn.model.StudentVO;

public interface StudentService {

	public List<StudentVO> getAll();
}
