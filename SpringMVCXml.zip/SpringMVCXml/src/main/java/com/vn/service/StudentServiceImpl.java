package com.vn.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.vn.model.StudentVO;

@Service
public class StudentServiceImpl implements StudentService {

	public List<StudentVO> getAll() {
		List<StudentVO> result = new ArrayList<StudentVO>();
		StudentVO vo = new StudentVO();
		vo.setBod(new Date());
		vo.setId("SV1");
		vo.setName("Sinh vien 1");
		result.add(vo);
		return result;
	}

}
