package com.vn.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.vn.entity.RowCount;
import com.vn.entity.Student;

public class InsertMapper2 implements RowMapper<RowCount> {
   public RowCount mapRow(ResultSet rs, int rowNum) throws SQLException {
	   RowCount row = new RowCount();
//      student.setId(rs.getInt("id"));
//      student.setName(rs.getString("name"));
//      student.setAge(rs.getInt("age"));
	   row.setRowNumber(rowNum);
      return row;
   }
}