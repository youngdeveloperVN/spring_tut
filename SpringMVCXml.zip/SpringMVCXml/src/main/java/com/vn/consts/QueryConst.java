package com.vn.consts;

public class QueryConst {
	public static final String STUDENT_DDL_CREATE = "CREATE...";
	public static final String STUDENT_DML_INSERT = "INSER...";
	public static final String STUDENT_DML_DELETE = "DELETE...";
}
